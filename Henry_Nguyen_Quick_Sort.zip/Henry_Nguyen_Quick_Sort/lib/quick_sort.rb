class QuickSort
  # Quick sort has average case time complexity O(nlogn), but worst
  # case O(n**2).

  # Not in-place. Uses O(n) memory.
  def self.sort1(array)
    return array if array.length < 2
    pivot = array[0]
    left = []
    right = []
    array[1..-1].each do |num|
      if num <= pivot 
        left << num 
      else 
        right << num
      end 

    end 

    QuickSort.sort1(left) + [pivot] + QuickSort.sort1(right)


  end

  # In-place.
  def self.sort2!(array, start = 0, length = array.length, &prc)
    prc ||= Proc.new{|x, y| x <=> y}

    return array if length < 2
    
    pivot = self.partition(array, start, length, &prc)
    
    left = pivot - start
    right  = length - (left + 1)
      self.sort2!(array, 0, left, &prc)
      self.sort2!(array, pivot + 1, right, &prc)

    array


  end

  def self.partition(array, start, length, &prc)
    prc ||= Proc.new {|x, y| x <=> y}

    pivot_idx = start
  
    barrier_idx = start
    (start + 1...start + length).each do |idx|
  
          
      if prc.call(array[pivot_idx], array[idx]) == 1
        barrier_idx += 1
        
        array[idx], array[barrier_idx ] = array[barrier_idx], array[idx]
      end 

    end 

  array[barrier_idx], array[pivot_idx] = array[pivot_idx], array[barrier_idx]

  barrier_idx
  end
end
