require_relative 'heap'
# require_relative 'heap_sort'

def k_largest_elements(array, k)
  heaped = Heap.new
  array.each do |num|
    heaped.push(num)
  end
  

end
